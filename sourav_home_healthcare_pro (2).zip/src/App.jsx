import React from 'react'

const WA = 'https://wa.me/919547095650'
const CALL = 'tel:+919547095650'

function Badge({children}){
  return <span className="badge">{children}</span>
}

function Card({title, price, children, premium}){
  return (
    <div className="card">
      <div className="card-head">
        <h3>{title}</h3>
        {premium && <span className="pill">Premium</span>}
      </div>
      <p className="card-body">{children}</p>
      <div className="price">{price}</div>
    </div>
  )
}

export default function App(){
  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">
          <div className="logo">SB</div>
          <div className="titles">
            <h1>Sourav Home Healthcare</h1>
            <p>Professional Home Healthcare • 24×7 Emergency Home Care</p>
          </div>
        </div>
        <div className="actions">
          <a className="btn wa" href={WA} target="_blank" rel="noreferrer">WhatsApp</a>
          <a className="btn call" href={CALL}>Call</a>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <h2>Compassionate Care,<br/>Right at Your Home</h2>
          <p>Home visit for: Post-operative dressing, Diabetic foot/Burn dressing, IV cannula & Saline, Injection (IV/IM/SC), Blood Collection, Stitch Removal (doctor advised), BP/Sugar check.</p>
          <div className="cta">
            <a className="btn primary" href={WA} target="_blank" rel="noreferrer">Book on WhatsApp</a>
            <a className="btn outline" href={CALL}>Call 9547095650</a>
          </div>
          <div className="chips">
            <Badge>Shapoorji</Badge>
            <Badge>New Town</Badge>
            <Badge>Akandakeshari</Badge>
            <Badge>Rajarhat</Badge>
          </div>
        </div>
        <div className="hero-art" aria-hidden />
      </section>

      <div className="features">
        <Badge>Doctor-advised procedures only</Badge>
        <Badge>Sterile kits & proper disposal</Badge>
        <Badge>Transparent pricing • No hidden fees</Badge>
      </div>

      <section className="grid">
        <h2>Services</h2>
        <div className="cards">
          <Card title="Post-operative Dressing" price="₹400–₹800" premium>
            Surgical wound care & follow-ups
          </Card>
          <Card title="Diabetic Foot / Burn Dressing" price="₹500–₹1200" premium>
            Advanced sterile dressing
          </Card>
          <Card title="IV Cannula & Saline Setup" price="₹500–₹900">
            Home IV support & monitoring
          </Card>
          <Card title="Injection (IV / IM / SC)" price="₹150–₹300">
            Doctor-prescribed only
          </Card>
          <Card title="Blood Collection at Home" price="₹150–₹250">
            Lab tie-up • e-reports
          </Card>
          <Card title="BP / Sugar Check" price="₹50–₹100">
            Vitals at your doorstep
          </Card>
        </div>
      </section>

      <section className="help">
        <div className="help-inner">
          <div>
            <h3>Need help now?</h3>
            <p>Fast response in Shapoorji / New Town / Rajarhat</p>
          </div>
          <div className="cta">
            <a className="btn wa" href={WA} target="_blank" rel="noreferrer">WhatsApp</a>
            <a className="btn call" href={CALL}>Call</a>
          </div>
        </div>
      </section>

      <footer className="foot">
        <p>© {new Date().getFullYear()} Sourav Home Healthcare • Verified Home Care Provider</p>
        <p>Timings: 7am–11:30am, 5pm–10pm (24×7 on-call for urgent dressing)</p>
      </footer>
    </div>
  )
}
